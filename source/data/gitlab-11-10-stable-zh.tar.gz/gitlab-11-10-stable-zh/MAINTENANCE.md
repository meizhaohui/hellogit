# GitLab Maintenance Policy

See [doc/policy/maintenance.md](doc/policy/maintenance.md)
