We’re closing our issue tracker on GitHub so we can focus on the GitLab.com project and respond to issues more quickly.

We encourage you to open an issue on the [GitLab.com issue tracker](https://gitlab.com/gitlab-org/gitlab-ce/issues). You can log into GitLab.com using your GitHub account.
