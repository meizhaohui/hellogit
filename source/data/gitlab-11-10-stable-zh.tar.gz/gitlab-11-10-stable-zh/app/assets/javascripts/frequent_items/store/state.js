export default () => ({
  namespace: '',
  storageKey: '',
  searchQuery: '',
  isLoadingItems: false,
  isFetchFailed: false,
  items: [],
});
