class ListMilestone {
  constructor(obj) {
    this.id = obj.id;
    this.title = obj.title;
  }
}

window.ListMilestone = ListMilestone;
