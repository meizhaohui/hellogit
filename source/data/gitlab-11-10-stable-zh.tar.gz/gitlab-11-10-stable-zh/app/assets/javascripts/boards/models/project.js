export default class IssueProject {
  constructor(obj) {
    this.id = obj.id;
    this.path = obj.path;
  }
}
