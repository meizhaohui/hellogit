export default {
  computed: {
    shouldRenderDraftRow: () => () => false,
    shouldRenderParallelDraftRow: () => () => false,
    draftForLine: () => () => ({}),
  },
};
