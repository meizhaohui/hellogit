export default {
  computed: {
    deployIconName() {
      return '';
    },
    shouldRenderDeployBoard() {
      return false;
    },
  },
  methods: {
    toggleDeployBoard() {},
  },
};
