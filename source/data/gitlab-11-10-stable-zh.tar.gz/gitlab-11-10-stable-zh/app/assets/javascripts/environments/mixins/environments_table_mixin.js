export default {
  methods: {
    shouldShowCanaryCallout() {
      return false;
    },
    shouldRenderDeployBoard() {
      return false;
    },
  },
};
