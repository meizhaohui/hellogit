export default {
  computed: {
    canaryCalloutProps() {},
  },
};
