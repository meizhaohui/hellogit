/**
 * Deploy boards are EE only.
 *
 * @param {Object} environment
 * @returns {Object}
 */
// eslint-disable-next-line import/prefer-default-export
export const setDeployBoard = (oldEnvironmentState, environment) => environment;
