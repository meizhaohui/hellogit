import 'jquery';

// common jQuery plugins
import 'jquery-ujs';
import 'vendor/jquery.endless-scroll';
import 'jquery.caret'; // must be imported before at.js
import 'at.js';
import 'vendor/jquery.scrollTo';
import 'jquery.waitforimages';
