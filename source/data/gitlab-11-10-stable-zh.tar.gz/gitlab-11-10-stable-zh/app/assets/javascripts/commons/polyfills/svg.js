import svg4everybody from 'svg4everybody';

// polyfill support for external SVG file references via <use xlink:href>
// @see https://css-tricks.com/svg-use-external-source/
svg4everybody();
