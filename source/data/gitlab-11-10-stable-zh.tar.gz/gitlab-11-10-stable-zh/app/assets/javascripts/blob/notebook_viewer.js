import renderNotebook from './notebook';

export default renderNotebook;
