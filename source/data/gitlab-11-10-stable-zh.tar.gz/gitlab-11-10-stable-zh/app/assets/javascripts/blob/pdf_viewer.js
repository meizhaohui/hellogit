import renderPDF from './pdf';

export default renderPDF;
