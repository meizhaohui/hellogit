export const GROUP_BADGE = 'group';
export const PROJECT_BADGE = 'project';
