export default () => ({
  imageUrl: '',
  isDeleting: false,
  linkUrl: '',
  renderedImageUrl: '',
  renderedLinkUrl: '',
});
